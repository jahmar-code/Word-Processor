// CS2211b 2023
// Assignment 4
// Jawaad Ahmar
// 251237757
// jahmar 
// 09/03/2023

// prototypes for word.c
word word_ini(void);
void word_free(word);
void word_str_cp(word w, char *str);
int word_cmp(char *str, word b);
void word_print(word w);
