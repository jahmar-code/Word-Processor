// CS2211b 2023
// Assignment 4
// Jawaad Ahmar
// 251237757
// jahmar 
// 09/03/2023

// a grouping of type definitions and prototypes for all files
#include "definitions.h"
#include "word.h"
#include "line.h"
#include "para.h"

