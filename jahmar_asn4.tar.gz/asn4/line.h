// CS2211b 2023
// Assignment 4
// Jawaad Ahmar
// 251237757
// jahmar 
// 09/03/2023

// prototypes for line.c
line line_ini(void);
void line_free(line l);
void line_add(line l, word w);
void line_print(line l);
int line_search(line l, char *str, int pos);

