// CS2211b 2023
// Assignment 4
// Jawaad Ahmar
// 251237757
// jahmar 
// 09/03/2023

// prototypes for para.c
para para_ini(void);
void para_free(para p);
void para_add(para p, line l);
void para_print(para p);
int para_search_print(para p, char *str);

